data:extend({
  {
    type = "custom-input",
    name = "rcalc-get-selection-tool",
    key_sequence = "ALT + X",
    action = "lua",
  },
  {
    type = "custom-input",
    name = "rcalc-linked-focus-search",
    key_sequence = "",
    linked_game_control = "focus-search",
  },
})
