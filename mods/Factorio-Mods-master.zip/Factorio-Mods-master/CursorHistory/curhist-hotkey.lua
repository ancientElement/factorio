data:extend(
{
	{
		type = "custom-input",
		name = "curhist_hotkey",
		key_sequence = "SHIFT + Q",
		consuming = "none"
	},
	{
		type = "custom-input",
		name = "curhist_back_hotkey",
		key_sequence = "CONTROL + SHIFT + Q",
		consuming = "none"
	}
}
)