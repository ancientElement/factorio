I've swiped the build.js and watch.js from https://github.com/MakuraYami/factorio-mods  I guess they got it from BarryKun ?

build zip file

node build <directory>
watch a directory.

This copies the mod over to the factorio mod directory and automatically applies changes.

node watch <directory>
For Windows %APPDATA%/.factorio/mods

For Linux ~/.factorio/mods

For Mac not supported

