data:extend(
{
	{
		type = "custom-input",
		name = "marc_hotkey",
		key_sequence = "CONTROL + N",
		consuming = "none"
	},
	{
		type = "custom-input",
		name = "marcalc_toggle",
		key_sequence = "CONTROL + ENTER",
		consuming = "none"
	}
}
)