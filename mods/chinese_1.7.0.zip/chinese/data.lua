require("datas.tinyequipment")
