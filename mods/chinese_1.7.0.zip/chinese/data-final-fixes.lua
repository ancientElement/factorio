require("datas.squeakthrough")

require("datas.tree_collision")

require("datas.inventorysize")

require("datas.tinyequipment")

require("datas.infinite-resources")

require("datas.stack")

require("datas.running-speed")

require("datas.pump")
