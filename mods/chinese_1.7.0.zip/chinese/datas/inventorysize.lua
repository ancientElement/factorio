if settings.startup["chinese-inventorysize-enable"].value then
    data.raw.character.character.inventory_size = settings.startup["chinese-inventorysize"].value
end
